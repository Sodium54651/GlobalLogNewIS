﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BDconnetcion3000
{
    public partial class StartMenu : Form
    {
        public StartMenu()
        {
            InitializeComponent();
            button2.Text = "Грузы";
        }



        private void button1_Click(object sender, EventArgs e)
        {
            
            Button baton = (Button)sender;

            MainMenu forma = new MainMenu(baton.Tag.ToString());
            forma.Text = naming(baton.Tag.ToString());
            forma.Show();

        }

        private string naming(string baton)
        {
            switch (baton)
            {
                case "pip":
                    return "Люди";

                case "num":
                    return "Грузы";

                case "chek":
                    return "Доставить и кто доставляет";

                case "ords":
                    return "Заказчик";
            }
            return "";
        }

    }
}
