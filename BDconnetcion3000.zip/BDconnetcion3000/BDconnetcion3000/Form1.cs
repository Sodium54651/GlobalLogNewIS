﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using wordic = Microsoft.Office.Interop.Word;
using System.IO;
using System.Drawing.Printing;
using Microsoft.Office.Interop.Word;

namespace BDconnetcion3000
{
    public partial class MainMenu : Form
    {
        private string Shabold = Directory.GetCurrentDirectory() + "\\Шаблоны\\"; 
        private bool printer = true;
        private bool searchmode = false;
        private string awsomeID = null;
        private string[] awsomeMas =  {"null0", "null1", "null2", "null3"};

        //путь к БД
        string bdpath;
        //далеее подклчюаемся
        SQLiteConnection connection;

        private string typeTablet;

        public MainMenu(string rh)
        {
            InitializeComponent();
            typeTablet = rh;
            changeName();
            bdpath = "URI = file:BDLiteSQL.db";
            connection = new SQLiteConnection(bdpath);

            SelectButon(baton1, EventArgs.Empty);
        }

        private void changeName()
        {
            switch (typeTablet)
            {
                //люди
                case "pip":
                    
                    l1.Text = "Id";
                    l2.Text = "Имя";
                    l3.Text = "Фамилия";
                    l4.Text = "Год";
                    break;
                //Грузы
                case "num":
                    l1.Text = "Id";
                    l2.Text = "ИМЯ";
                    l3.Text = "Вес в КГ";
                    l4.Text = "Объём М^2";
                    break;
                 //место доставки
                case "chek":
                    l1.Text = "Id";
                    l2.Text = "Адрес";
                    l3.Text = "Способ доставки";
                    l4.Text = "Доставщик";
                    break;
                //заказы \ клиенты
                case "ords":
                    l1.Text = "Id";
                    l2.Text = "ИМЯ";
                    l3.Text = "Фамилия";
                    l4.Text = "Телефон";
                    break;
            }
        }
//Рандон
        private string randa()
        {
            Random f = new Random();
            int dt = DateTime.Now.Year + DateTime.Now.Month + DateTime.Now.Second - DateTime.Now.Minute - DateTime.Now.Millisecond;
            string u = "";
            for (int rh = 0; rh < dt.ToString().Length - 1; rh++)
                u += ((char)f.Next(97, 122)).ToString() + dt.ToString()[rh];
            return u;
        }

//чтение с БД
        private void SelectButon(object sender, EventArgs e)
        {
            //делаем запрос
        //для общего 
            string sql = "";
            if (printer)
            {
                
                switch (typeTablet)
                {
                    case "pip":
                        sql = "SELECT * FROM pipole";
                        break;

                    case "num":
                        sql = "SELECT * FROM shipment";
                        break;

                    case "chek":
                        sql = "SELECT * FROM ToShipment";
                        break;

                    case "ords":
                        sql = "SELECT * FROM orders";
                        break;
                }
            }
        //для принтера
            else
            {
                printer = true;
                switch (typeTablet)
                {
                    case "pip":
                        sql = "SELECT * FROM pipole WHERE id = " + $"\'{awsomeID.ToString()}\'";
                        Shabold += "dogovorForEmploer.docx";
                        break;

                    case "num":
                        sql = "SELECT * FROM shipment WHERE id = " + $"\'{awsomeID.ToString()}\'";
                        Shabold += "dogovorShip.docx";
                        break;

                    case "chek":
                        sql = "SELECT * FROM ToShipment WHERE id = " + $"\'{awsomeID.ToString()}\'";
                        Shabold += "dogovorToAdress.docx";
                        break;

                    case "ords":
                        sql = "SELECT * FROM orders WHERE id = " + $"\'{awsomeID.ToString()}\'";
                        Shabold += "dogovorClient.docx";
                        break;
                }
            }
            if (searchmode)
            {
                searchmode = false;
                string search = searchbox.Text;
                switch (typeTablet)
                { 
                    case "pip":
                        sql = $"SELECT * FROM pipole where lower(first_name)  LIKE lower('%{search}%') OR Last_name LIKE '%{search}%' OR age LIKE '%{search}%'";
                        break;

                    case "num":
                        sql = $"SELECT * FROM shipment WHERE LOWER(name) LIKE LOWER('%{search}%') OR weight LIKE '%{search}%' OR volum LIKE '%{search}%'";
                        break;

                    case "chek":
                        sql = $"SELECT * FROM ToShipment WHERE lower(name) LIKE lower('%{search}%') OR lower(rh) LIKE lower('%{search}%') OR " +
                          $"lower(diliviler) LIKE lower('%{search}%')";
                        break;

                    case "ords":
                        sql = $"SELECT * FROM orders WHERE " +
                          $"lower(name) LIKE lower('%{search}%') OR " +
                          $"lower(lastname) LIKE lower('%{search}%') OR " +
                          $"tel LIKE '%{search}%'";
                        break;
                }
            }

            //проверяем подключённый статус хотя можно и не делать 
            if (connection.State != ConnectionState.Open)
                connection.Open();

            //записываем запрос и подключаемую базу данных
            SQLiteCommand cmd = new SQLiteCommand(sql, connection);
            //выполняем чтрение строки с таой информации
            using (SQLiteDataReader dr = cmd.ExecuteReader())
            {
                //очищаем окошко на всякий
                sqlWindow.ColumnCount = 0;
                //присваиваем ему число колоночек
                sqlWindow.ColumnCount = dr.FieldCount;

                //подсчёт количества колоночек
                for (int rh = 0; rh < dr.FieldCount; rh++)
                {
                    sqlWindow.Columns[rh].HeaderText = dr.GetName(rh);
                }
                //начинаем считывать и предавать их в массив а после в таблицу по строчно
                while (dr.Read())
                {
                    
                    //читаем колличетсво строчек
                    string[] row = new string[dr.FieldCount];
                    awsomeMas = row;
                    for (int rh = 0; rh < dr.FieldCount; rh++)
                    {
                        row[rh] = dr.GetValue(rh).ToString();
                    }
                    sqlWindow.Rows.Add(row);
                }

            }


        }
//вставка в БД
        private void inserterBut_Click(object sender, EventArgs e)
        {
            //рандомим индекс
            id.Text = randa().ToString();

            string sql = "";
            switch (typeTablet)
            {
                case "pip":
                    sql = $"INSERT INTO \"main\".\"pipole\" (\"id\", \"first_name\", \"last_name\", \"age\") VALUES ('{id.Text}', '{firstname.Text}', '{lastname.Text}', {age.Text})";
                    break;

                case "num":
                    sql = $"INSERT INTO \"main\".\"shipment\" (\"id\", \"name\", \"weight\", \"volum\") VALUES ('{id.Text}', '{firstname.Text}', {lastname.Text}, {age.Text})";
                    break;

                case "chek":
                    sql = $"INSERT INTO \"main\".\"ToShipment\" (\"id\", \"name\", \"rh\", \"diliviler\") VALUES ('{id.Text}', '{firstname.Text}', '{lastname.Text}', '{age.Text}')";
                    break;

                case "ords":
                    sql = $"INSERT INTO \"main\".\"orders\" (\"id\", \"name\", \"lastname\", \"tel\") VALUES ('{id.Text}', '{firstname.Text}', '{lastname.Text}', '{age.Text}')";
                    break;
            }


            if (id.Text is "" || firstname.Text is "" || lastname.Text is "" || age.Text is "")
                MessageBox.Show("Не");
            else
            {
                if (connection.State != ConnectionState.Open)
                    connection.Open();

                //записываем запрос и подключаемую базу данных
                SQLiteCommand cmd = new SQLiteCommand(sql, connection);
                //выполняем чтрение строки с таой информации
                using (cmd.ExecuteReader())
                {

                }
                SelectButon(sender, e);
            }
        }
//Удаление откуда... Верно из БД
        private void button2_Click(object sender, EventArgs e)
        {
            string sql = "";
            switch (typeTablet)
            {
                case "pip":
                    //DELETE FROM table_name WHERE column_name = value;
                    sql = $"DELETE FROM \"main\".\"pipole\" WHERE \"id\" = {id.Text}";
                    break;

                case "num":
                    sql = $"DELETE FROM \"main\".\"shipment\" WHERE \"id\" = {id.Text}";
                    break;

                case "chek":
                    sql = $"DELETE FROM \"main\".\"ToShipment\" WHERE \"id\" = {id.Text}";
                    break;

                case "ords":
                    sql = $"DELETE FROM \"main\".\"orders\" WHERE \"id\" = {id.Text}";
                    break;
            }


            if (id.Text is "")
                MessageBox.Show("Не", "Напиши индекс того, что удаляем вот отюда ^");
            else
            {
                if (connection.State != ConnectionState.Open)
                    connection.Open();

                //записываем запрос и подключаемую базу данных
                SQLiteCommand cmd = new SQLiteCommand(sql, connection);
                //выполняем чтрение строки с таой информации
                using (cmd.ExecuteReader())
                {

                }
                SelectButon(sender, e);
            }
        }
//Обновление данных где?... правильно в БД
        private void button3_Click(object sender, EventArgs e)
        {

            string sql = "";
            switch (typeTablet)
            {
                case "pip":
                    //UPDATE table_name
                    //SET column1 = value1, column2 = value2
                    //WHERE condition;
                    sql = $"UPDATE \"main\".\"pipole\" " +
                        $"SET \"first_name\" = '{firstname.Text}', \"last_name\" = '{lastname.Text}', \"age\" = {age.Text} " +
                        $"WHERE \"id\" = {id.Text}";
                    break;

                case "num":
                    //sql = $"INSERT INTO \"main\".\"shipment\" (\"id\", \"name\", \"weight\", \"volum\") VALUES ({id.Text}, '{firstname.Text}', {lastname.Text}, {age.Text})";

                    sql = $"UPDATE \"main\".\"shipment\" " +
                        $"SET \"name\" = '{firstname.Text}', \"weight\" = {lastname.Text}, \"volum\" = {age.Text} " +
                        $"WHERE \"id\" = {id.Text}";
                    break;

                case "chek":
                    //sql = $"INSERT INTO \"main\".\"ToShipment\" (\"id\", \"name\", \"rh\", \"diliviler\") VALUES ({id.Text}, '{firstname.Text}', '{lastname.Text}', '{age.Text}')";

                    sql = $"UPDATE \"main\".\"ToShipment\" " +
                        $"SET \"name\" = '{firstname.Text}', \"rh\" = '{lastname.Text}', \"diliviler\" = '{age.Text}' " +
                        $"WHERE \"id\" = {id.Text}";
                    break;

                case "ords":
                    sql = $"INSERT INTO \"main\".\"orders\" (\"id\", \"name\", \"lastname\", \"tel\") VALUES ({id.Text}, '{firstname.Text}', '{lastname.Text}', '{age.Text}')";

                    sql = $"UPDATE \"orders\" " +
                      $"SET \"name\" = '{firstname.Text}', \"lastname\" = '{lastname.Text}', \"tel\" = '{age.Text}' " +
                      $"WHERE \"id\" = {id.Text}";
                    break;
            }


            if (id.Text is "")
                MessageBox.Show("Не");
            else
            {
                if (connection.State != ConnectionState.Open)
                    connection.Open();

                //записываем запрос и подключаемую базу данных
                SQLiteCommand cmd = new SQLiteCommand(sql, connection);
                //выполняем чтрение строки с таой информации
                using (cmd.ExecuteReader())
                {

                }
                SelectButon(sender, e);
            }
        }
//Очистка окошек
        private void button4_Click(object sender, EventArgs e)
        {
            id.Text = "";
            firstname.Text = "";
            lastname.Text = "";
            age.Text = "";
        }
//готовим договор
        private void button5_Click(object sender, EventArgs e)
        {
            printer = false;
            awsomeID = id.Text;
            SelectButon(sender, e);

            var wordap = new wordic.Application();
            wordap.Visible = false;

            var worddoc = wordap.Documents.Open(Shabold);
            ReplaceWord("{name_of}", awsomeMas[1], worddoc);
            ReplaceWord("{weight_of}", awsomeMas[2], worddoc);
            ReplaceWord("{volium_of}", awsomeMas[3], worddoc);


            string fileName = $"договор_{awsomeMas[1]}_{DateTime.Now:yyyy-MM-dd_HH-mm-ss}.docx";
            string outPath = Path.Combine(Directory.GetCurrentDirectory(), "Договора", fileName);

            worddoc.SaveAs2(outPath, wordic.WdSaveFormat.wdFormatXMLDocument);

            //что бы не орал об ошибки надоел
            try
            {
                worddoc.Application.Quit();
                worddoc.Close();
            }
            catch { }
            
        }

        private void ReplaceWord(string place, string textOn, wordic.Document worddoc)
        {
            var losos = worddoc.Content;
            losos.Find.ClearFormatting();
            losos.Find.Execute(FindText: place, ReplaceWith: textOn);
        }

        private void batonSortiron_Click(object sender, EventArgs e)
        {
            sqlWindow.Sort(sqlWindow.Columns[1], ListSortDirection.Ascending);
        }

        private void BatonSearchion_Click(object sender, EventArgs e)
        {
            searchmode = true;
            SelectButon(sender, e);
        }
    }
}
